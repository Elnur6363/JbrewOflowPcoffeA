﻿using System;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
namespace BrewFlow
{
    public partial class MainForm
    {
        // Окно оплаты заказа.
        void PayDialog()
        {
            decimal gross;
            using(var d=new Db()) gross=Ops.Gross(d,order);
            decimal amount=gross;
            using(var view=new PaymentForm())
            {
                var f=view;
                Ops.Need(amount <= view.cash.Maximum,"Сумма превышает допустимый предел оплаты");
                var methods=view.methods;
                var cash=view.cash;
                
                var card=view.card;
                var sbp=view.sbp;
                Action set=()=>
                {
                    decimal discount = Ops.DiscountAmount(gross, view.discount.SelectedIndex);
                    amount = gross - discount;
                    view.summary.Text = "Сумма: " + gross.ToString("N2") + " руб. | Скидка: " + discount.ToString("N2") + " руб.";
                    view.label1.Text = "К оплате: " + amount.ToString("N2") + " руб.";
                    cash.Value=methods.Text=="Наличные"?amount:0;
                    card.Value=methods.Text=="Карта"?amount:0;
                    sbp.Value=methods.Text=="СБП"?amount:0;
                    cash.Enabled=card.Enabled=sbp.Enabled=methods.Text=="Смешанная";
                }
                ;
                methods.SelectedIndexChanged+=(s,e)=>set();
                view.discount.SelectedIndexChanged+=(s,e)=>set();
                set();
                var box=view.box;
                view.label1.Text = "К оплате: "+amount.ToString("N2")+" руб.";
                view.button1Action = ()=>
                {
                    if(UI.Confirm("Подтвердить получение оплаты?"))
                    {
                        Ops.Pay(u,order,methods.Text,cash.Value,card.Value,sbp.Value,view.discount.SelectedIndex);
                        f.DialogResult=DialogResult.OK;
                    }
                }
                ;
                view.button2Action = ()=>f.Close();
                if(f.ShowDialog(this)==DialogResult.OK)
                {
                    MessageBox.Show("Оплата сохранена в базе Access.");
                    order=0;
                    Queue();
                }
            }
        }
        // Показываю список заказов.
        void Queue()
        {
            Page("Очередь заказов");
            var view=new QueueForm();
            var filter=view.filter;
            var search=view.search;
            var g=view.g;
            // Какие кнопки можно нажать при этом статусе.
            Action updateButtons = delegate
            {
                string state = g.CurrentRow == null ? "" : Convert.ToString(g.CurrentRow.Cells["Статус"].Value);
                view.button2.Enabled = state == "Новый";
                view.button4.Enabled = state == "Оплачен";
                view.button5.Enabled = state == "Оплачен" || state == "Готов";
                view.button6.Enabled = state == "Новый" || (u.Shift && (state == "Оплачен" || state == "Готов"));
                view.button7.Enabled = u.Shift && state == "Выдан";
            };
            Action load=()=>
            {
                var t=T("SELECT o.ID,o.OrderNo AS [Заказ],o.ShiftID AS [Смена],o.CreatedAt AS [Время],o.StatusText AS [Статус],o.[Discount] AS [Скидка],o.Total AS [Итого],v.Amount AS [Сумма возврата],o.NoteText AS [Комментарий] FROM [Заказы] o LEFT JOIN [Возвраты] v ON o.ID=v.OrderID ORDER BY o.ID DESC");
                foreach(DataRow r in t.Rows.Cast<DataRow>().ToArray())if((filter.Text!="Все"&&Ops.S(r,"Статус")!=filter.Text)||Ops.S(r,"Заказ").IndexOf(search.Text,StringComparison.OrdinalIgnoreCase)<0)t.Rows.Remove(r);
                g.DataSource=t;
                updateButtons();
            }
            ;
            g.SelectionChanged += delegate { if (g.Columns.Contains("Статус")) updateButtons(); };
            filter.SelectedIndexChanged+=(s,e)=>UI.Safe(load);
            search.TextChanged+=(s,e)=>UI.Safe(load);
            view.button1Action = load;
            view.button2Action = ()=>
            {
                int selectedOrder=UI.Selected(g);
                using(var d=new Db())Ops.Need(Ops.S(Ops.Row(d,"SELECT * FROM [Заказы] WHERE ID=?",selectedOrder),"StatusText")=="Новый","Редактировать можно только новый заказ");
                order=selectedOrder;
                Sales();
            }
            ;
            view.button3Action = ()=>ShowTable("Состав заказа",T("SELECT ProductName AS [Позиция],Qty AS [Количество],UnitPrice AS [Цена] FROM [СоставЗаказов] WHERE OrderID=?",UI.Selected(g)));
            view.button4Action = ()=>
            {
                Ops.Advance(u,UI.Selected(g),"Готов");
                load();
            }
            ;
            view.button5Action = ()=>
            {
                Ops.Advance(u,UI.Selected(g),"Выдан");
                load();
            }
            ;
            view.button6Action = ()=>
            {
                string r=UI.Prompt("Отмена","Причина");
                if(r!=null&&UI.Confirm("Отменить заказ?"))
                {
                    Ops.Cancel(u,UI.Selected(g),r,false);
                    load();
                }
            }
            ;
            view.button7.Visible = u.Shift;
            view.button7Action = ()=>
            {
                string r=UI.Prompt("Возврат","Причина возврата");
                if(r!=null&&UI.Confirm("Оформить полный возврат?"))
                {
                    Ops.Cancel(u,UI.Selected(g),r,true);
                    load();
                    MessageBox.Show("Возврат оформлен и сохранён в базе.");
                }
            }
            ;
            view.purchasesButton.Click += delegate
            {
                UI.Safe(delegate
                {
                    ShowTable("Покупки из Access", T("SELECT o.OrderNo AS [Заказ], o.CreatedAt AS [Дата], l.ProductName AS [Товар], l.Qty AS [Количество], l.UnitPrice AS [Цена], o.[Discount] AS [Скидка заказа], o.Total AS [Итого заказа], o.StatusText AS [Статус], v.Amount AS [Сумма возврата] FROM ([Заказы] o INNER JOIN [СоставЗаказов] l ON o.ID=l.OrderID) LEFT JOIN [Возвраты] v ON o.ID=v.OrderID WHERE EXISTS (SELECT p.ID FROM [Оплаты] p WHERE p.OrderID=o.ID) ORDER BY o.ID DESC"));
                });
            };
            Mount(view);
            load();
        }
        void ShowTable(string title,DataTable data)
        {
            using(var view=new TableForm())
            {
                view.Text=title;
                view.dataGrid.DataSource = data;
                view.ShowDialog(this);
            }
        }
    }
}
