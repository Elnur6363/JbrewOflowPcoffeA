﻿using System;
using System.Windows.Forms;

namespace BrewFlow
{
    public partial class StockForm : Form
    {
        public StockForm()
        {
            InitializeComponent();
        }

        internal Action button1Action;
        private void button1_Click(object sender, EventArgs e)
        {
            if (button1Action != null) UI.Safe(button1Action);
        }

        internal Action button2Action;
        private void button2_Click(object sender, EventArgs e)
        {
            if (button2Action != null) UI.Safe(button2Action);
        }

        internal Action button3Action;
        private void button3_Click(object sender, EventArgs e)
        {
            if (button3Action != null) UI.Safe(button3Action);
        }

        internal Action button4Action;
        private void button4_Click(object sender, EventArgs e)
        {
            if (button4Action != null) UI.Safe(button4Action);
        }

        internal Action button5Action;
        private void button5_Click(object sender, EventArgs e)
        {
            if (button5Action != null) UI.Safe(button5Action);
        }
    }
}
