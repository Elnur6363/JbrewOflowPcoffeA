﻿using System.Windows.Forms;
namespace BrewFlow { public partial class TableForm : Form { public TableForm() { InitializeComponent(); } } }
