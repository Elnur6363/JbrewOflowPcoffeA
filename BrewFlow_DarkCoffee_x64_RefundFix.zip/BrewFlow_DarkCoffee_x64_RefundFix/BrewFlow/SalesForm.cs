﻿using System;
using System.Data;
using System.Drawing;
using System.Collections.Generic;
using System.Windows.Forms;

namespace BrewFlow
{
    public partial class SalesForm : Form
    {
        private Employee employee;
        public int OrderId { get; private set; }
        public event Action OrderChanged;
        public event Action OpenQueue;
        public event Action PayOrder;
        private readonly List<Panel> extraCards = new List<Panel>();

        public SalesForm() { InitializeComponent(); }

        public void Setup(Employee user, int order)
        {
            employee = user;
            grid.BindingContext = new BindingContext();
            OrderId = order;
            using (Db db = new Db())
            {
                if (OrderId > 0 && db.Int("SELECT COUNT(*) FROM [Заказы] WHERE ID=? AND StatusText=? AND ShiftID=?", OrderId, "Новый", Ops.Shift(db)) == 0)
                { OrderId = 0; }
                if (OrderId == 0)
                    OrderId = db.Int("SELECT TOP 1 ID FROM [Заказы] WHERE ShiftID=? AND EmployeeID=? AND StatusText=? ORDER BY ID DESC", Ops.Shift(db), user.Id, "Новый");
            }
            category.SelectedIndexChanged += FilterChanged;
            search.TextChanged += FilterChanged;
            LoadProducts();
            RefreshOrder();
        }

        private void FilterChanged(object sender, EventArgs e) { UI.Safe(LoadProducts); }
        // Показываю все товары. Пять карточек уже есть на форме.
        private void LoadProducts()
        {
            foreach (Panel card in extraCards) card.Dispose();
            extraCards.Clear();
            Panel[] panels = { productPanel1, productPanel2, productPanel3, productPanel4, productPanel5 };
            PictureBox[] photos = { photo1, photo2, photo3, photo4, photo5 };
            Button[] buttons = { productButton1, productButton2, productButton3, productButton4, productButton5 };
            foreach (Panel panel in panels) panel.Visible = false;
            int index = 0;
            using (Db db = new Db())
            {
                DataTable table = db.Table("SELECT ID,ProductName,CategoryName,Price,ImageName FROM [Меню] WHERE ActiveFlag=True ORDER BY ID");
                foreach (DataRow row in table.Rows)
                {
                    string name = Ops.S(row, "ProductName");
                    if (category.Text != "Все" && category.Text != Ops.S(row, "CategoryName")) continue;
                    if (name.IndexOf(search.Text, StringComparison.CurrentCultureIgnoreCase) < 0) continue;
                    if (index < panels.Length)
                    {
                        FillCard(panels[index], photos[index], buttons[index], row);
                    }
                    else
                    {
                        // Если добавили новый товар, делаю ещё одну карточку.
                        Panel panel = new Panel { Size = new Size(156,125), Margin = new Padding(5), BackColor = Color.FromArgb(55, 37, 28) };
                        PictureBox photo = new PictureBox { Location = new Point(3,3), Size = new Size(150,75), SizeMode = PictureBoxSizeMode.Zoom };
                        Button button = new Button { Location = new Point(3,81), Size = new Size(150,41), BackColor = Color.FromArgb(132, 79, 44), ForeColor = Color.FromArgb(255, 241, 222), FlatStyle = FlatStyle.Flat, UseVisualStyleBackColor = false };
                        button.Click += ProductButton_Click;
                        panel.Controls.Add(photo);
                        panel.Controls.Add(button);
                        cards.Controls.Add(panel);
                        extraCards.Add(panel);
                        FillCard(panel, photo, button, row);
                    }
                    index++;
                }
            }
        }
        private void FillCard(Panel panel, PictureBox photo, Button button, DataRow row)
        {
            button.Tag = Ops.I(row, "ID");
            button.Text = Ops.S(row, "ProductName") + "\n" + Ops.M(row, "Price").ToString("0.##") + " руб.";
            UI.LoadPhoto(photo, Ops.S(row, "ImageName"));
            panel.Visible = true;
        }
        // Обновляю список товаров и итоговую сумму.
        private void RefreshOrder()
        {
            using (Db db = new Db())
            {
                DataTable lines = db.Table("SELECT ID,ProductName AS [Товар],Qty AS [Кол-во],UnitPrice AS [Цена],Qty*UnitPrice AS [Сумма] FROM [СоставЗаказов] WHERE OrderID=?",OrderId);
                grid.DataSource = lines;
                if (grid.Columns.Count > 0) grid.Columns[0].Visible = false;
                bool hasOrder = OrderId > 0;
                button4.Enabled = hasOrder && lines.Rows.Count > 0;
                button1.Enabled = button5.Enabled = hasOrder;
                button6.Enabled = button7.Enabled = hasOrder && lines.Rows.Count > 0;
                button8.Enabled = !hasOrder;
                label4.Text = "Заказ ещё не создан";
                total.Text = "ИТОГО: 0,00 руб.";
                if (hasOrder)
                {
                    DataRow row = Ops.Row(db,"SELECT * FROM [Заказы] WHERE ID=?",OrderId);
                    label4.Text = Ops.S(row,"OrderNo") + " — Новый";
                    note.Text = Ops.S(row,"NoteText");
                    total.Text = "ИТОГО: " + Ops.M(row,"Total").ToString("N2") + " руб.";
                }
                else { note.Clear(); }
            }
            if (OrderChanged != null) OrderChanged();
        }
        private void ProductButton_Click(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            UI.Safe(delegate { AddProduct(Convert.ToInt32(button.Tag)); });
        }
        // Добавляю выбранный товар.
        private void AddProduct(int product)
        {
            if (OrderId == 0)
            {
                OrderId = Ops.NewOrder(employee);
                if (OrderChanged != null) OrderChanged();
            }
            Ops.Add(employee,OrderId,product,(int)qty.Value);
            // Записываю заметку к заказу.
            Ops.Apply(employee,OrderId,note.Text);
            RefreshOrder();
        }
        private void Apply()
        {
            Ops.Apply(employee,OrderId,note.Text);
            RefreshOrder();
        }
        private void button1_Click(object sender, EventArgs e) { UI.Safe(Apply); }
        private void button4_Click(object sender, EventArgs e) { UI.Safe(Pay); }
        private void Pay() { Apply(); if (PayOrder != null) PayOrder(); }
        private void button5_Click(object sender, EventArgs e) { UI.Safe(CancelOrder); }
        private void CancelOrder()
        {
            if (!UI.Confirm("Отменить текущий заказ?")) return;
            Ops.Cancel(employee,OrderId,"Отмена сотрудником",false);
            OrderId = 0;
            RefreshOrder();
        }
        private void button6_Click(object sender, EventArgs e) { UI.Safe(RemoveLine); }
        private void RemoveLine() { Ops.Remove(employee,OrderId,UI.Selected(grid)); RefreshOrder(); }
        private void button7_Click(object sender, EventArgs e) { UI.Safe(ClearOrder); }
        private void ClearOrder() { if (UI.Confirm("Очистить товары?")) { Ops.Remove(employee,OrderId,0); RefreshOrder(); } }
        private void button8_Click(object sender, EventArgs e) { UI.Safe(NewOrder); }
        private void NewOrder() { if (OrderId == 0) { OrderId = Ops.NewOrder(employee); RefreshOrder(); } }
        private void button9_Click(object sender, EventArgs e) { if (OpenQueue != null) UI.Safe(OpenQueue); }
    }
}
