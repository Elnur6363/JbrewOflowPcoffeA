﻿using System;
using System.Windows.Forms;

namespace BrewFlow
{
    public partial class ProductForm : Form
    {
        public ProductForm()
        {
            InitializeComponent();
        }

        internal Action button1Action;
        private void button1_Click(object sender, EventArgs e)
        {
            if (button1Action != null) UI.Safe(button1Action);
        }
    }
}
