﻿using System;
using System.Data;
using System.Windows.Forms;
namespace BrewFlow
{
    public partial class LoginForm:Form
    {
        public Employee Employee;
        public LoginForm()
        {
            InitializeComponent();
        }
        private void EnterClick(object sender,EventArgs e)
        {
            UI.Safe(()=>
            {
                using(var d=new Db(true))
                {
                    var t=d.Table("SELECT e.*,r.RoleName FROM [Сотрудники] e INNER JOIN [Роли] r ON e.RoleID=r.ID WHERE e.LoginName=?",login.Text.Trim());DataRow r=t.Rows.Count==0?null:t.Rows[0];bool ok=r!=null&&Convert.ToBoolean(r["ActiveFlag"])&&Db.Hash(password.Text,Ops.S(r,"SaltText"))==Ops.S(r,"HashText");int id=r==null?0:Ops.I(r,"ID");d.Log(id,ok?"Вход":"Неудачная попытка входа",login.Text.Trim());d.Commit();if(!ok)
                    {
                        password.Clear();throw new Exception("Неверный логин или пароль, либо учётная запись отключена");
                    }
                    Employee=new Employee
                    {
                        Id=id,Name=Ops.S(r,"FullName"),Role=Ops.I(r,"RoleID"),RoleName=Ops.S(r,"RoleName")
                    }
                    ;DialogResult=DialogResult.OK;
                }
            }
            );
        }
    }
}
