﻿using System;
using System.Data;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using System.Linq;
namespace BrewFlow {
 static class UI {
  public static Color Cream=Color.FromArgb(55, 37, 28), Brown=Color.FromArgb(246, 228, 210), Tan=Color.FromArgb(132, 79, 44), Paper=Color.FromArgb(29, 21, 17);
  public static void Safe(Action a){try{a();}catch(Exception e){MessageBox.Show(e.Message,"BrewFlow",MessageBoxButtons.OK,MessageBoxIcon.Warning);}}
  public static bool Confirm(string s){return MessageBox.Show(s,"Подтверждение",MessageBoxButtons.YesNo,MessageBoxIcon.Question)==DialogResult.Yes;}
  public static Button Button(string text,Action action,int w=145){var b=new Button{Text=text,Width=w,Height=36,BackColor=Tan,ForeColor=Color.FromArgb(255, 241, 222),UseVisualStyleBackColor=false,FlatStyle=FlatStyle.Flat,Font=new Font("Segoe UI",10,FontStyle.Bold),Margin=new Padding(4)};b.FlatAppearance.BorderSize=0;b.Click+=(s,e)=>Safe(action);return b;}
  public static Label Label(string t,int size=11){return new Label{Text=t,AutoSize=true,ForeColor=Brown,Font=new Font("Segoe UI",size),Margin=new Padding(4,9,4,4)};}
  public static TextBox Text(string t="",int max=255,int w=175){return new TextBox{BackColor=Color.FromArgb(65, 45, 35),ForeColor=Color.FromArgb(255, 241, 222),Text=t,MaxLength=max,Width=w,Margin=new Padding(4,7,4,4)};}
  public static ComboBox Combo(params string[] items){var c=new ComboBox{BackColor=Color.FromArgb(65, 45, 35),ForeColor=Color.FromArgb(255, 241, 222),DropDownStyle=ComboBoxStyle.DropDownList,Width=175,Margin=new Padding(4,7,4,4)};c.Items.AddRange(items);if(c.Items.Count>0)c.SelectedIndex=0;return c;}
  public static ComboBox Lookup(DataTable t,string display,string value,bool none=false){if(none){t.Columns[display].ReadOnly=false;t.Columns[value].ReadOnly=false;var r=t.NewRow();r[value]=0;r[display]="— нет —";t.Rows.InsertAt(r,0);}var c=Combo();c.BindingContext=new BindingContext();c.DisplayMember=display;c.ValueMember=value;c.DataSource=t;return c;}
  public static void BindLookup(ComboBox c,DataTable t,string display,string value,bool none=false){if(none){t.Columns[display].ReadOnly=false;t.Columns[value].ReadOnly=false;var r=t.NewRow();r[value]=0;r[display]="— нет —";t.Rows.InsertAt(r,0);}c.BindingContext=new BindingContext();c.DisplayMember=display;c.ValueMember=value;c.DataSource=t;}
  public static void LoadPhoto(PictureBox p, string file)
  {
      if (p.Image != null) { p.Image.Dispose(); p.Image = null; }
      p.Disposed -= DisposePhoto;
      p.Disposed += DisposePhoto;
      if (String.IsNullOrWhiteSpace(file)) return;
      string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"Images",Path.GetFileName(file));
      if (!File.Exists(path)) return;
      try { using (Image img = Image.FromFile(path)) p.Image = new Bitmap(img); }
      catch (ArgumentException) { }
      catch (IOException) { }
      catch (System.Runtime.InteropServices.ExternalException) { }
  }
  static void DisposePhoto(object sender, EventArgs e)
  {
      PictureBox p = (PictureBox)sender;
      if (p.Image != null) p.Image.Dispose();
  }
  public static int Id(ComboBox c)
  {
      int id;
      return Int32.TryParse(Convert.ToString(c.SelectedValue), out id) ? id : 0;
  }
  public static NumericUpDown Num(decimal max=1000000,int digits=2,decimal value=0){return new NumericUpDown{BackColor=Color.FromArgb(65, 45, 35),ForeColor=Color.FromArgb(255, 241, 222),Minimum=0,Maximum=max,DecimalPlaces=digits,Value=Math.Max(0,Math.Min(max,value)),Width=110,Margin=new Padding(4,7,4,4),ThousandsSeparator=true};}
  public static FlowLayoutPanel Bar(params Control[] items){var p=new FlowLayoutPanel{Dock=DockStyle.Top,AutoSize=true,AutoSizeMode=AutoSizeMode.GrowAndShrink,WrapContents=true,BackColor=Paper,Padding=new Padding(5),Margin=new Padding(0)};p.Controls.AddRange(items);return p;}
  public static DataGridView Grid(DataTable data){var g=new DataGridView{Dock=DockStyle.Fill,ReadOnly=true,AllowUserToAddRows=false,AllowUserToDeleteRows=false,AutoSizeColumnsMode=DataGridViewAutoSizeColumnsMode.Fill,SelectionMode=DataGridViewSelectionMode.FullRowSelect,MultiSelect=false,RowHeadersVisible=false,BackgroundColor=Paper,BorderStyle=BorderStyle.None,EnableHeadersVisualStyles=false,AutoSizeRowsMode=DataGridViewAutoSizeRowsMode.AllCells};g.ColumnHeadersDefaultCellStyle.BackColor=Color.FromArgb(79, 51, 34);g.DefaultCellStyle.BackColor=Color.FromArgb(39, 28, 22);g.DefaultCellStyle.ForeColor=Color.FromArgb(255, 241, 222);g.AlternatingRowsDefaultCellStyle.ForeColor=Color.FromArgb(255, 241, 222);g.GridColor=Color.FromArgb(98, 68, 51);g.ColumnHeadersDefaultCellStyle.ForeColor=Color.FromArgb(255, 241, 222);g.ColumnHeadersDefaultCellStyle.Font=new Font("Segoe UI",10,FontStyle.Bold);g.DefaultCellStyle.SelectionBackColor=Tan;g.DefaultCellStyle.SelectionForeColor=Color.FromArgb(255, 241, 222);g.AlternatingRowsDefaultCellStyle.BackColor=Color.FromArgb(48, 34, 26);g.DataSource=data;return g;}
  public static int Selected(DataGridView g){if(g.CurrentRow==null)throw new Exception("Выберите запись");return Convert.ToInt32(g.CurrentRow.Cells[0].Value);}
  public static string Prompt(string title,string label,string initial="",int max=300){using(var f=new Form{Text=title,StartPosition=FormStartPosition.CenterParent,Size=new Size(510,200),BackColor=Cream,ForeColor=Color.FromArgb(255, 241, 222),FormBorderStyle=FormBorderStyle.FixedDialog,MaximizeBox=false,MinimizeBox=false}){var l=Label(label);l.Location=new Point(12,12);var t=Text(initial,max,455);t.Location=new Point(16,45);var ok=Button("Подтвердить",()=>{f.DialogResult=DialogResult.OK;});ok.Location=new Point(16,90);var no=Button("Отмена",()=>{f.DialogResult=DialogResult.Cancel;});no.Location=new Point(180,90);f.Controls.AddRange(new Control[]{l,t,ok,no});f.AcceptButton=ok;f.CancelButton=no;return f.ShowDialog()==DialogResult.OK?t.Text:null;}}
  public static PictureBox Photo(string file,int w,int h){var p=new PictureBox{Width=w,Height=h,SizeMode=PictureBoxSizeMode.Zoom,BackColor=Paper};string path=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"Images",file??"");if(File.Exists(path)){using(var img=Image.FromFile(path))p.Image=new Bitmap(img);}p.Disposed+=(s,e)=>{if(p.Image!=null)p.Image.Dispose();};return p;}
 }
}
