﻿using System;
using System.Drawing;
using System.Windows.Forms;
namespace BrewFlow {
partial class TableForm {
private System.ComponentModel.IContainer components = null;
protected override void Dispose(bool disposing) { if(disposing && components != null) components.Dispose(); base.Dispose(disposing); }
internal DataGridView dataGrid;
private void InitializeComponent() {
this.dataGrid = new DataGridView();
this.dataGrid.DefaultCellStyle.BackColor = Color.FromArgb(39, 28, 22);
this.dataGrid.DefaultCellStyle.ForeColor = Color.FromArgb(246, 228, 210);
this.dataGrid.AlternatingRowsDefaultCellStyle.ForeColor = Color.FromArgb(246, 228, 210);
this.dataGrid.GridColor = Color.FromArgb(98, 68, 51);
((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
this.SuspendLayout();
this.dataGrid.Name = "dataGrid";
this.dataGrid.Dock = DockStyle.Fill;
this.dataGrid.ReadOnly = true;
this.dataGrid.AllowUserToAddRows = false;
this.dataGrid.AllowUserToDeleteRows = false;
this.dataGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
this.dataGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
this.dataGrid.MultiSelect = false;
this.dataGrid.RowHeadersVisible = false;
this.dataGrid.BackgroundColor = Color.FromArgb(29, 21, 17);
this.dataGrid.BorderStyle = BorderStyle.None;
this.dataGrid.EnableHeadersVisualStyles = false;
this.dataGrid.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
this.dataGrid.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(79, 51, 34);
this.dataGrid.ColumnHeadersDefaultCellStyle.ForeColor = Color.FromArgb(255, 241, 222);
this.dataGrid.DefaultCellStyle.SelectionBackColor = Color.FromArgb(132, 79, 44);
this.dataGrid.DefaultCellStyle.SelectionForeColor = Color.FromArgb(255, 241, 222);
this.dataGrid.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(48, 34, 26);
this.Controls.Add(this.dataGrid);
this.AutoScaleMode = AutoScaleMode.Font;
this.ClientSize = new Size(900, 510);
this.BackColor = Color.FromArgb(29, 21, 17);
this.ForeColor = Color.FromArgb(246, 228, 210);
this.Font = new Font("Segoe UI",10F);
this.Text = "Просмотр данных";
this.Name = "TableForm";
this.StartPosition = FormStartPosition.CenterParent;
this.FormBorderStyle = FormBorderStyle.FixedDialog;
this.MaximizeBox = false;
this.MinimizeBox = false;
((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
this.ResumeLayout(false);
this.PerformLayout();
}
}
}