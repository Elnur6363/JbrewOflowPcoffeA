﻿using System;
using System.Data;
using System.Windows.Forms;

namespace BrewFlow
{
    public partial class ShiftForm : Form
    {
        private Employee employee;
        private decimal expectedCash;
        public event Action ShiftChanged;
        public event Action OpenSales;

        public ShiftForm() { InitializeComponent(); }

        public void Setup(Employee user)
        {
            employee = user;
            actual.ValueChanged += ActualChanged;
            RefreshShift();
        }

        // Загружаю данные смены из базы.
        private void RefreshShift()
        {
            using (Db db = new Db())
            {
                int id = Ops.Shift(db);
                bool opened = id > 0;
                initial.Enabled = !opened;
                button1.Enabled = !opened;
                actual.Enabled = opened;
                reason.Enabled = opened;
                button2.Enabled = opened;
                goSales.Enabled = opened;
                expectedCash = opened ? Ops.Expected(db, id) : 0;
                label1.Text = opened ? "Смена № " + id + " открыта" : "Смена закрыта. Введите сумму и нажмите «Открыть смену».";
                decimal cash = opened ? Ops.Payments(db,id,"Наличные") : 0;
                decimal card = opened ? Ops.Payments(db,id,"Карта") : 0;
                decimal sbp = opened ? Ops.Payments(db,id,"СБП") : 0;
                decimal refund = opened ? db.Money("SELECT SUM(Amount) FROM [Возвраты] WHERE ShiftID=?", id) : 0;
                label2.Text = "Наличные: " + cash.ToString("N2") + " | Карта: " + card.ToString("N2") + " | СБП: " + sbp.ToString("N2") + " | Возвраты: " + refund.ToString("N2");
                label4.Text = "Продажи: " + (cash+card+sbp-refund).ToString("N2") + " руб.";
                label5.Text = "Должно быть в кассе: " + expectedCash.ToString("N2") + " руб.";
                actual.Value = Math.Max(0, Math.Min(actual.Maximum, expectedCash));
                g.DataSource = db.Table("SELECT s.ID AS [Номер], e.FullName AS [Ответственный], s.OpenedAt AS [Открытие], s.ClosedAt AS [Закрытие], s.StartCash AS [Начало], s.ActualCash AS [Факт], s.Difference AS [Расхождение], s.StatusText AS [Статус], s.NoteText AS [Комментарий] FROM [Смены] s INNER JOIN [Сотрудники] e ON s.EmployeeID=e.ID ORDER BY s.ID DESC");
            }
            ActualChanged(this, EventArgs.Empty);
            if (ShiftChanged != null) ShiftChanged();
        }

        // Начальная сумма при открытии смены.
        private void button1_Click(object sender, EventArgs e)
        {
            if (employee == null) return;
            UI.Safe(OpenCurrentShift);
        }
        private void OpenCurrentShift()
        {
            Ops.OpenShift(employee, initial.Value);
            RefreshShift();
            MessageBox.Show("Смена открыта! Теперь можно оформлять заказы.");
        }
        private void button2_Click(object sender, EventArgs e)
        {
            if (employee == null) return;
            UI.Safe(CloseCurrentShift);
        }
        private void CloseCurrentShift()
        {
            if (!UI.Confirm("Закрыть смену? Проверьте наличные в кассе.")) return;
            Ops.CloseShift(employee, actual.Value, reason.Text);
            Ops.EnsureOpenShift(employee);
            initial.Value = 0;
            reason.Clear();
            RefreshShift();
            MessageBox.Show("Смена закрыта. Новая смена открыта автоматически.");
        }
        private void ActualChanged(object sender, EventArgs e)
        {
            diff.Text = "Расхождение: " + (actual.Value - expectedCash).ToString("N2") + " руб.";
        }
        private void GoSales_Click(object sender, EventArgs e)
        {
            if (OpenSales != null) UI.Safe(OpenSales);
        }
    }
}
