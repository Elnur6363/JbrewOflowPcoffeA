﻿using System;
using System.Windows.Forms;

namespace BrewFlow
{
    public partial class RecipeForm : Form
    {
        public RecipeForm()
        {
            InitializeComponent();
        }

        internal Action button1Action;
        private void button1_Click(object sender, EventArgs e)
        {
            if (button1Action != null) UI.Safe(button1Action);
        }

        internal Action button2Action;
        private void button2_Click(object sender, EventArgs e)
        {
            if (button2Action != null) UI.Safe(button2Action);
        }

        internal Action button3Action;
        private void button3_Click(object sender, EventArgs e)
        {
            if (button3Action != null) UI.Safe(button3Action);
        }
    }
}
