﻿using System;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
namespace BrewFlow
{
    public partial class MainForm
    {
        // Загружаю меню из базы.
        void MenuPage()
        {
            Page("Меню и технологические карты");
            var view=new MenuForm();
            var g=view.g;
            view.g.DataSource = T("SELECT ID,ProductName AS [Наименование],CategoryName AS [Категория],Price AS [Цена],ActiveFlag AS [Доступность],ImageName AS [Фото] FROM [Меню] WHERE ActiveFlag=True OR ProductName NOT IN ('Чай 300 мл','Айс-кофе','Вода') ORDER BY ID");
            view.button1Action = ()=>EditProduct(0);
            view.button2Action = ()=>EditProduct(UI.Selected(g));
            view.button3Action = ()=>Recipe(UI.Selected(g));
            view.button4Action = ()=>ShowTable("История цен",T("SELECT Price AS [Цена],ValidFrom AS [Действует с],EmployeeID AS [Сотрудник] FROM [ИсторияЦен] WHERE ProductID=? ORDER BY ID DESC",UI.Selected(g)));
            view.button6Action = MenuPage;
            Mount(view);
        }
        // Добавление или изменение товара.
        void EditProduct(int id)
        {
            DataRow r=id==0?null:T("SELECT * FROM [Меню] WHERE ID=?",id).Rows[0];
            using(var view=new ProductForm())
            {
                var f=view;
                var name=view.name;
                view.name.Text = r==null?"":Ops.S(r,"ProductName");
                var cat=view.cat;
                if(r!=null)cat.SelectedItem=Ops.S(r,"CategoryName");
                var price=view.price;
                view.price.Value = Math.Max(0m, Math.Min(view.price.Maximum, r==null?0:Ops.M(r,"Price")));
                var active=view.active;
                view.active.Checked = r==null||Convert.ToBoolean(r["ActiveFlag"]);
                var img=view.img;
                view.img.Items.AddRange(new[]
                {
                    ""
                }
                .Concat(Directory.GetFiles(Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"Images")).Select(Path.GetFileName)).ToArray());
                if(view.img.Items.Count>0) view.img.SelectedIndex=0;
                if(r!=null)img.SelectedItem=Ops.S(r,"ImageName");
                var box=view.box;
                view.button1Action = ()=>
                {
                    Ops.Need(u.Manager&&!String.IsNullOrWhiteSpace(name.Text),"Введите название");
                    using(var d=new Db(true))
                    {
                        int product=id;
                        if(id==0)product=d.Insert("INSERT INTO [Меню] (ProductName,CategoryName,Price,ActiveFlag,ImageName) VALUES (?,?,?,?,?)",name.Text.Trim(),cat.Text,price.Value,active.Checked,img.Text);
                        else d.Exec("UPDATE [Меню] SET ProductName=?,CategoryName=?,Price=?,ActiveFlag=?,ImageName=? WHERE ID=?",name.Text.Trim(),cat.Text,price.Value,active.Checked,img.Text,id);
                        if(r==null||price.Value!=Ops.M(r,"Price"))
                        {
                            d.Exec("INSERT INTO [ИсторияЦен] (ProductID,EmployeeID,Price,ValidFrom) VALUES (?,?,?,?)",product,u.Id,price.Value,DateTime.Now);
                            d.Log(u.Id,"Изменение цены",name.Text+": "+price.Value);
                        }
                        d.Log(u.Id,"Меню",name.Text);
                        d.Commit();
                    }
                    f.DialogResult=DialogResult.OK;
                }
                ;
                if(f.ShowDialog(this)==DialogResult.OK)MenuPage();
            }
        }
        // Настройка продуктов для одной порции.
        void Recipe(int id)
        {
            Page("Технологическая карта");
            var view=new RecipeForm();
            string table="[Техкарты]",key="ProductID";
            var ing=view.ing;
            UI.BindLookup(view.ing, T("SELECT ID,IngredientName FROM [Ингредиенты] WHERE IngredientName NOT IN ('Чай','Лёд','Лед') ORDER BY IngredientName"), "IngredientName", "ID");
            var qty=view.qty;
            var g=view.g;
            view.g.DataSource = T("SELECT r.ID,i.IngredientName AS [Ингредиент],i.UnitName AS [Единица],r.Qty AS [Расход] FROM "+table+" r INNER JOIN [Ингредиенты] i ON r.IngredientID=i.ID WHERE r."+key+"=?",id);
            view.button1Action = ()=>
            {
                Ops.Need(qty.Value>0&&UI.Id(ing)>0,"Укажите расход");
                using(var d=new Db(true))
                {
                    if(d.Exec("UPDATE "+table+" SET Qty=? WHERE "+key+"=? AND IngredientID=?",(double)qty.Value,id,UI.Id(ing))==0)d.Exec("INSERT INTO "+table+" ("+key+",IngredientID,Qty) VALUES (?,?,?)",id,UI.Id(ing),(double)qty.Value);
                    d.Log(u.Id,"Технологическая карта",id.ToString());
                    d.Commit();
                }
                Recipe(id);
            }
            ;
            view.button2Action = ()=>
            {
                if(UI.Confirm("Удалить ингредиент из техкарты?"))
                {
                    using(var d=new Db(true))
                    {
                        d.Exec("DELETE FROM "+table+" WHERE ID=?",UI.Selected(g));
                        d.Log(u.Id,"Технологическая карта",id.ToString());
                        d.Commit();
                    }
                    Recipe(id);
                }
            }
            ;
            view.button3Action = ()=>
            {
                MenuPage();
            }
            ;
            Mount(view);
        }
        // Показываю остатки на складе.
        void StockPage()
        {
            Page("Склад и остатки");
            var view=new StockForm();
            var t=T("SELECT ID,IngredientName AS [Ингредиент],UnitName AS [Единица],StockQty AS [Остаток],MinQty AS [Минимум] FROM [Ингредиенты] WHERE IngredientName NOT IN ('Чай','Лёд','Лед') ORDER BY ID");
            t.Columns.Add("Состояние",typeof(string));
            foreach(DataRow r in t.Rows)r["Состояние"]=Convert.ToDouble(r["Остаток"])<Convert.ToDouble(r["Минимум"])?"Ниже минимума":"Норма";
            var g=view.g;
            view.g.DataSource = t;
            g.CellFormatting+=(s,e)=>
            {
                if(e.Value!=null&&Convert.ToString(e.Value)=="Ниже минимума")
                {
                    e.CellStyle.BackColor=Color.FromArgb(79, 32, 36);
                    e.CellStyle.ForeColor=Color.FromArgb(255, 193, 193);
                }
            }
            ;
            var type=view.type;
            type.SelectedIndexChanged += delegate { view.label2.Text = type.Text == "Установить остаток" ? "Новый остаток" : "Количество"; };
            var qty=view.qty;
            var reason=view.reason;
            var top=view.top;
            view.button1Action = ()=>
            {
                if(UI.Confirm("Провести складскую операцию?"))
                {
                    Ops.Stock(u,UI.Selected(g),type.Text,(double)qty.Value,reason.Text);
                    StockPage();
                }
            }
            ;
            var bar=view.bar;
            view.button2Action = ()=>ShowTable("Движения склада",T("SELECT MovedAt AS [Дата],MoveType AS [Операция],DeltaQty AS [Изменение],ReasonText AS [Описание],EmployeeID AS [Сотрудник],OrderID AS [Заказ] FROM [ДвиженияСклада] WHERE IngredientID=? ORDER BY ID DESC",UI.Selected(g)));
            view.button3Action = StockPage;
            view.button4Action = ()=>EditIngredient(0);
            view.button4.Visible = u.Manager;
            view.button5Action = ()=>EditIngredient(UI.Selected(g));
            view.button5.Visible = u.Manager;
            Mount(view);
        }
        // Изменение ингредиента.
        void EditIngredient(int id)
        {
            var r=id==0?null:T("SELECT * FROM [Ингредиенты] WHERE ID=?",id).Rows[0];
            using(var view=new IngredientForm())
            {
                var f=view;
                var name=view.name;
                view.name.Text = r==null?"":Ops.S(r,"IngredientName");
                var units=view.units;
                if(r!=null)units.SelectedItem=Ops.S(r,"UnitName");
                units.Enabled=id==0;
                var min=view.min;
                view.min.Value = Math.Max(0m, Math.Min(view.min.Maximum, r==null?0:Ops.M(r,"MinQty")));
                var box=view.box;
                view.button1Action = ()=>
                {
                    Ops.Need(!String.IsNullOrWhiteSpace(name.Text),"Введите название");
                    using(var d=new Db(true))
                    {
                        if(id==0)d.Exec("INSERT INTO [Ингредиенты] (IngredientName,UnitName,StockQty,MinQty) VALUES (?,?,?,?)",name.Text,units.Text,0d,(double)min.Value);
                        else d.Exec("UPDATE [Ингредиенты] SET IngredientName=?,MinQty=? WHERE ID=?",name.Text,(double)min.Value,id);
                        d.Log(u.Id,"Справочник склада",name.Text);
                        d.Commit();
                    }
                    f.DialogResult=DialogResult.OK;
                }
                ;
                if(f.ShowDialog(this)==DialogResult.OK)StockPage();
            }
        }
    }
}
