﻿using System;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
namespace BrewFlow { public partial class MainForm:Form {
 Employee u; int order=0; public bool Logout; string current="";
 public MainForm(){InitializeComponent();}
 // Показываю разделы, доступные сотруднику.
 public MainForm(Employee employee) : this()
 {
     u = employee;
     WindowState = FormWindowState.Maximized;
     navButton2.Visible = u.Sales;
     navButton3.Visible = u.Sales;
     navButton4.Visible = u.Manager;
     navButton6.Visible = u.Manager || u.Shift;
     navButton7.Visible = u.Shift;
     navButton9.Visible = u.Admin;
     navButton1.Click += HomeClick;
     navButton2.Click += SalesClick;
     navButton3.Click += QueueClick;
     navButton4.Click += MenuClick;
     navButton6.Click += StockClick;
     navButton7.Click += ShiftClick;
     navButton9.Click += AdminClick;
     navButton11.Click += LogoutClick;
     navButton12.Click += ExitClick;
     Shown += HomeClick;
     backupTimer = new Timer();
     backupTimer.Interval = 3600000;
     backupTimer.Tick += BackupTick;
     backupTimer.Start();
     FormClosed += MainClosed;
 }
 Timer backupTimer;
 void HomeClick(object sender, EventArgs e) { UI.Safe(delegate { Ops.EnsureOpenShift(u); Home(); }); }
 void SalesClick(object sender, EventArgs e) { UI.Safe(Sales); }
 void QueueClick(object sender, EventArgs e) { UI.Safe(Queue); }
 void MenuClick(object sender, EventArgs e) { UI.Safe(MenuPage); }
 void StockClick(object sender, EventArgs e) { UI.Safe(StockPage); }
 void ShiftClick(object sender, EventArgs e) { UI.Safe(ShiftPage); }
 void AdminClick(object sender, EventArgs e) { UI.Safe(Admin); }
 void LogoutClick(object sender, EventArgs e)
 {
     if (!UI.Confirm("Сменить сотрудника и вернуться к окну входа?")) return;
     Logout = true;
     Close();
 }
 void ExitClick(object sender, EventArgs e) { if (UI.Confirm("Завершить работу?")) Close(); }
 void BackupTick(object sender, EventArgs e)
 {
     try { if (Db.BackupDue()) Db.Backup(); }
     catch (Exception ex) { System.Diagnostics.Debug.WriteLine(ex.Message); }
 }
 void MainClosed(object sender, FormClosedEventArgs e) { if (backupTimer != null) backupTimer.Dispose(); }
 int ActiveShift()
 {
     using (Db db = new Db()) { return Ops.Shift(db); }
 }
 void UpdateHeader()
 {
     int id = ActiveShift();
     session.Text = u.Name + "\n" + (id > 0 ? "Смена № " + id + " открыта" : "Смена закрыта");
 }
 // Очищаю место для следующего окна.
 void Page(string title)
 {
     current = title;
     section.Text = title;
     UpdateHeader();
     while (content.Controls.Count > 0) content.Controls[0].Dispose();
 }
 DataTable T(string sql,params object[] args){using(var d=new Db())return d.Table(sql,args);}
 void Mount(Form view){view.TopLevel=false;view.FormBorderStyle=FormBorderStyle.None;view.Dock=DockStyle.Fill;content.Controls.Add(view);view.Show();}
 // Главная страница.
 void Home()
 {
     Page("Главная");
     HomeForm view = new HomeForm();
     UI.LoadPhoto(view.heroPhoto, "1.png");
     int id = ActiveShift();
     view.shiftStatus.Text = id == 0 ? "Смена закрыта" : "Смена № " + id + " открыта";
     view.startButton.Visible = u.Shift || u.Sales;
     if (id == 0 && u.Shift)
     {
         view.welcomeLabel.Text = "1. Откройте смену.\n2. Добавьте товары в заказ.\n3. Оплатите и выдайте заказ.";
         view.startButton.Text = "Открыть смену";
         view.startButton.Click += ShiftClick;
     }
     else if (id == 0 && u.Sales)
     {
         view.welcomeLabel.Text = "Попросите старшего смены\nоткрыть смену.\nДля входа: shift.";
         view.startButton.Text = "Сменить сотрудника";
         view.startButton.Click += LogoutClick;
     }
     else if (u.Sales)
     {
         view.welcomeLabel.Text = "Смена открывается автоматически.\nМожно сразу оформлять заказы.";
         view.startButton.Text = "Оформить заказ";
         view.startButton.Click += SalesClick;
     }
     else
         view.welcomeLabel.Text = "Выберите нужный раздел слева.";
     Mount(view);
 }
 // Открываю окно продаж.
 void Sales()
 {
     Ops.EnsureOpenShift(u);
     Page("Оформление заказа");
     SalesForm view = new SalesForm();
     view.Setup(u, order);
     order = view.OrderId;
     view.OpenQueue += delegate { order = view.OrderId; Queue(); };
     view.PayOrder += delegate { order = view.OrderId; PayDialog(); };
     view.OrderChanged += delegate { order = view.OrderId; };
     Mount(view);
     if (view.split.Width >= 640)
         view.split.SplitterDistance = Math.Max(300, Math.Min(view.split.Width - 330, view.split.Width * 48 / 100));
 }
 // Открываю окно смены.
 void ShiftPage()
 {
     Page("Открытие и закрытие смены");
     ShiftForm view = new ShiftForm();
     view.Setup(u);
     view.ShiftChanged += delegate { UpdateHeader(); };
     view.OpenSales += delegate { Sales(); };
     Mount(view);
 }

} }
