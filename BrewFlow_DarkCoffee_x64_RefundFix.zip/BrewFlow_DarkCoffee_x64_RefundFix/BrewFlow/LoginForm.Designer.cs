﻿namespace BrewFlow
{
    partial class LoginForm
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }
        private void InitializeComponent()
        {
            this.login = new System.Windows.Forms.TextBox();
            this.login.BackColor = System.Drawing.Color.FromArgb(65, 45, 35);
            this.login.ForeColor = System.Drawing.Color.FromArgb(255, 241, 222);
            this.password = new System.Windows.Forms.TextBox();
            this.password.BackColor = System.Drawing.Color.FromArgb(65, 45, 35);
            this.password.ForeColor = System.Drawing.Color.FromArgb(255, 241, 222);
            this.enter = new System.Windows.Forms.Button();
            this.enter.UseVisualStyleBackColor = false;
            this.title = new System.Windows.Forms.Label();
            this.subtitle = new System.Windows.Forms.Label();
            this.l1 = new System.Windows.Forms.Label();
            this.l2 = new System.Windows.Forms.Label();
            this.hint = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // Поле для логина
            this.login.Location = new System.Drawing.Point(75, 157);
            this.login.Size = new System.Drawing.Size(360, 28);
            this.login.MaxLength = 50;
            this.login.Name = "login";
            this.login.TabIndex = 0;
            this.login.Text = "shift";
            // Поле для пароля
            this.password.Location = new System.Drawing.Point(75, 220);
            this.password.Size = new System.Drawing.Size(360, 28);
            this.password.UseSystemPasswordChar = true;
            this.password.MaxLength = 100;
            this.password.Name = "password";
            this.password.TabIndex = 1;
            // Кнопка входа
            this.enter.Text = "Войти";
            this.enter.BackColor = System.Drawing.Color.FromArgb(157, 91, 48);
            this.enter.ForeColor = System.Drawing.Color.FromArgb(255, 241, 222);
            this.enter.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.enter.Location = new System.Drawing.Point(75, 276);
            this.enter.Size = new System.Drawing.Size(360, 44);
            this.enter.Name = "enter";
            this.enter.TabIndex = 2;
            this.enter.Click += new System.EventHandler(this.EnterClick);
            // Название кофейни
            this.title.Text = "BrewFlow";
            this.title.Font = new System.Drawing.Font("Segoe Print", 30F, System.Drawing.FontStyle.Bold);
            this.title.ForeColor = System.Drawing.Color.FromArgb(235, 183, 124);
            this.title.Location = new System.Drawing.Point(25, 12);
            this.title.Size = new System.Drawing.Size(460, 76);
            this.title.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.title.Name = "title";
            this.title.TabIndex = 3;
            // Подпись под названием
            this.subtitle.Text = "Рабочее место сотрудника кофейни";
            this.subtitle.ForeColor = System.Drawing.Color.FromArgb(246, 228, 210);
            this.subtitle.Location = new System.Drawing.Point(25, 88);
            this.subtitle.Size = new System.Drawing.Size(460, 30);
            this.subtitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.subtitle.Name = "subtitle";
            this.subtitle.TabIndex = 4;
            // Подпись логина
            this.l1.Text = "Логин *";
            this.l1.Location = new System.Drawing.Point(75, 133);
            this.l1.AutoSize = true;
            this.l1.ForeColor = System.Drawing.Color.FromArgb(246, 228, 210);
            this.l1.Name = "l1";
            this.l1.TabIndex = 5;
            // Подпись пароля
            this.l2.Text = "Пароль *";
            this.l2.Location = new System.Drawing.Point(75, 196);
            this.l2.AutoSize = true;
            this.l2.ForeColor = System.Drawing.Color.FromArgb(246, 228, 210);
            this.l2.Name = "l2";
            this.l2.TabIndex = 6;
            this.BackColor = System.Drawing.Color.FromArgb(29, 21, 17);
            this.ForeColor = System.Drawing.Color.FromArgb(246, 228, 210);
            this.hint.Location = new System.Drawing.Point(28, 330);
            this.hint.Size = new System.Drawing.Size(454, 105);
            this.hint.Text = "Для начала работы: shift (старший смены)\nНачальный пароль: Brew2026!\nДругие логины: barista, manager, admin";
            this.hint.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.hint.Name = "hint";
            this.Controls.Add(this.hint);
            this.ClientSize = new System.Drawing.Size(510, 445);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Text = "BrewFlow — вход персонала";
            this.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular);
            this.AcceptButton = this.enter;
            this.Controls.Add(this.title);
            this.Controls.Add(this.subtitle);
            this.Controls.Add(this.l1);
            this.Controls.Add(this.l2);
            this.Controls.Add(this.login);
            this.Controls.Add(this.password);
            this.Controls.Add(this.enter);
            this.Name = "LoginForm";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.TextBox login;
        private System.Windows.Forms.TextBox password;
        private System.Windows.Forms.Button enter;
        private System.Windows.Forms.Label title;
        private System.Windows.Forms.Label subtitle;
        private System.Windows.Forms.Label l1;
        private System.Windows.Forms.Label l2;
        private System.Windows.Forms.Label hint;
    }
}
