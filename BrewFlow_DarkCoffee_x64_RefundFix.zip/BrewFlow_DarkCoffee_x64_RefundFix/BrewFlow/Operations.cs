﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
namespace BrewFlow
{
    static class Ops
    {
        public static void Need(bool condition,string message)
        {
            if(!condition)throw new InvalidOperationException(message);
        }
        public static decimal Round(decimal n)
        {
            return Math.Round(n,2,MidpointRounding.AwayFromZero);
        }
        public static DataRow Row(Db d,string sql,params object[] a)
        {
            var t=d.Table(sql,a);
            Need(t.Rows.Count>0,"Запись не найдена");
            return t.Rows[0];
        }
        public static int I(DataRow r,string s)
        {
            return Convert.ToInt32(r[s]);
        }
        public static decimal M(DataRow r,string s)
        {
            return Convert.ToDecimal(r[s]);
        }
        public static string S(DataRow r,string s)
        {
            return Convert.ToString(r[s]);
        }
        public static int Shift(Db d)
        {
            return d.Int("SELECT TOP 1 ID FROM [Смены] WHERE StatusText=? ORDER BY ID DESC","Открыта");
        }
        // Автоматически открываю смену с 0 рублей в кассе.
        public static void EnsureOpenShift(Employee u)
        {
            if (!u.Sales) return;
            using (Db d = new Db(true))
            {
                if (Shift(d) == 0)
                {
                    int responsible = u.Id;
                    int id = d.Insert("INSERT INTO [Смены] (EmployeeID,OpenedAt,StartCash,StatusText) VALUES (?,?,?,?)", responsible,DateTime.Now,0m,"Открыта");
                    d.Log(u.Id,"Автоматическое открытие смены",id.ToString());
                }
                d.Commit();
            }
        }
        // Создаю новый заказ.
        public static int NewOrder(Employee u)
        {
            Need(u.Sales,"Нет прав");
            EnsureOpenShift(u);
            using(var d=new Db(true))
            {
                int shift=Shift(d);
                Need(shift>0,"Сначала откройте смену");
                Need(d.Exec("UPDATE [Смены] SET StatusText=? WHERE ID=? AND StatusText=?","Открыта",shift,"Открыта")==1,"Смена закрыта");
                int id=d.Insert("INSERT INTO [Заказы] (ShiftID,EmployeeID,CreatedAt,StatusText,NoteText,Total,[Discount]) VALUES (?,?,?,?,?,?,?)",shift,u.Id,DateTime.Now,"Новый","",0m,0m);
                d.Exec("UPDATE [Заказы] SET OrderNo=? WHERE ID=?","BF-"+DateTime.Now.Year+"-"+id.ToString("D5"),id);
                d.Log(u.Id,"Новый заказ",id.ToString());
                d.Commit();
                return id;
            }
        }
        static DataRow Draft(Db d,Employee u,int id)
        {
            Need(u.Sales&&id>0,"Выберите новый заказ");
            Need(d.Exec("UPDATE [Заказы] SET StatusText=? WHERE ID=? AND StatusText=?","Новый",id,"Новый")==1,"Состав оплаченного или отменённого заказа менять нельзя");
            var r=Row(d,"SELECT * FROM [Заказы] WHERE ID=?",id);
            Need(Shift(d)==I(r,"ShiftID"),"Смена закрыта");
            return r;
        }
        // Считаю стоимость всех товаров.
        public static decimal Gross(Db d,int id)
        {
            return Round(d.Money("SELECT SUM(Qty*UnitPrice) FROM [СоставЗаказов] WHERE OrderID=?",id));
        }
        static void Reset(Db d,int id)
        {
            d.Exec("UPDATE [Заказы] SET Total=?,[Discount]=0 WHERE ID=?",Gross(d,id),id);
        }
        // Добавляю товар в заказ.
        public static void Add(Employee u,int id,int product,int qty)
        {
            Need(qty>0&&qty<=999,"Количество от 1 до 999");
            using(var d=new Db(true))
            {
                Draft(d,u,id);
                var p=Row(d,"SELECT * FROM [Меню] WHERE ID=? AND ActiveFlag=True",product);
                d.Exec("INSERT INTO [СоставЗаказов] (OrderID,ProductID,ProductName,CategoryName,Qty,UnitPrice) VALUES (?,?,?,?,?,?)",id,product,S(p,"ProductName"),S(p,"CategoryName"),qty,M(p,"Price"));
                Reset(d,id);
                d.Commit();
            }
        }
        // Убираю товар из заказа.
        public static void Remove(Employee u,int id,int line)
        {
            using(var d=new Db(true))
            {
                Draft(d,u,id);
                if(line==0)d.Exec("DELETE FROM [СоставЗаказов] WHERE OrderID=?",id);
                else d.Exec("DELETE FROM [СоставЗаказов] WHERE ID=? AND OrderID=?",line,id);
                Reset(d,id);
                d.Commit();
            }
        }
        public static void Apply(Employee u,int id,string note)
        {
            Need(note.Length<=300,"Комментарий не более 300 символов");
            using(var d=new Db(true))
            {
                Draft(d,u,id);
                d.Exec("UPDATE [Заказы] SET Total=?,[Discount]=0,NoteText=? WHERE ID=?",Gross(d,id),note,id);
                d.Commit();
            }
        }
        static void Move(Db d,Employee u,int ingredient,int order,double delta,string type,string reason)
        {
            Need(d.Exec("UPDATE [Ингредиенты] SET StockQty=StockQty+? WHERE ID=? AND StockQty+?>=-0.000000001",delta,ingredient,delta)==1,"Недостаточный остаток ингредиента №"+ingredient);
            d.Exec("UPDATE [Ингредиенты] SET StockQty=0 WHERE ID=? AND StockQty<0",ingredient);
            d.Exec("INSERT INTO [ДвиженияСклада] (IngredientID,EmployeeID,OrderID,MovedAt,MoveType,DeltaQty,ReasonText) VALUES (?,?,?,?,?,?,?)",ingredient,u.Id,order,DateTime.Now,type,delta,reason);
        }
        // Скидка только на этот заказ.
        public static decimal DiscountAmount(decimal gross,int choice)
        {
            Need(choice>=0&&choice<=2,"Выберите скидку");
            decimal discount=choice==1?Round(gross*0.10m):choice==2?50m:0m;
            return Math.Min(gross,discount);
        }
        // Сохраняю оплату и списываю продукты.
        public static void Pay(Employee u,int id,string method,decimal cash,decimal card,decimal sbp,int choice)
        {
            using(var d=new Db(true))
            {
                var o=Draft(d,u,id);
                Need(d.Int("SELECT COUNT(*) FROM [СоставЗаказов] WHERE OrderID=?",id)>0,"Добавьте позиции");
                decimal gross=Gross(d,id);
                decimal discount=DiscountAmount(gross,choice);
                decimal total=gross-discount;
                Need(cash>=0&&card>=0&&sbp>=0&&Round(cash+card+sbp)==total,"Сумма оплаты должна совпадать с итогом");
                Need(new[]
                {
                    "Наличные","Карта","СБП","Смешанная"
                }
                .Contains(method),"Выберите способ оплаты");
                Need(total>0||method!="Смешанная","При нулевой сумме выберите один способ оплаты");
                Need(method=="Смешанная"?new[]
                {
                    cash,card,sbp
                }
                .Count(x=>x>0)>=2:method=="Наличные"?card==0&&sbp==0:method=="Карта"?cash==0&&sbp==0:cash==0&&card==0,"Проверьте разбивку оплаты");
                var needed=new Dictionary<int,double>();
                foreach(DataRow line in d.Table("SELECT * FROM [СоставЗаказов] WHERE OrderID=?",id).Rows)
                {
                    int p=I(line,"ProductID"),q=I(line,"Qty");
                    Need(d.Int("SELECT COUNT(*) FROM [Меню] WHERE ID=? AND ActiveFlag=True",p)==1,"Позиция недоступна");
                    var rec=d.Table("SELECT * FROM [Техкарты] WHERE ProductID=?",p);
                    Need(rec.Rows.Count>0,"Нет технологической карты: "+S(line,"ProductName"));
                    foreach(DataRow r in rec.Rows)Acc(needed,I(r,"IngredientID"),Convert.ToDouble(r["Qty"])*q);
                }
                foreach(var pair in needed)
                {
                    var ingredient=Row(d,"SELECT * FROM [Ингредиенты] WHERE ID=?",pair.Key);
                    double avail=Convert.ToDouble(ingredient["StockQty"]);
                    Need(avail+1e-9>=pair.Value,"Недостаточно на складе: "+S(ingredient,"IngredientName"));
                    Move(d,u,pair.Key,id,-pair.Value,"Продажа","По технологической карте");
                }
                string[] methods=
                {
                    "Наличные","Карта","СБП"
                }
                ;
                decimal[] amounts=
                {
                    cash,card,sbp
                }
                ;
                for(int i=0;i<3;i++)if(amounts[i]>0||(total==0&&methods[i]==method))d.Exec("INSERT INTO [Оплаты] (OrderID,MethodName,Amount,PaidAt) VALUES (?,?,?,?)",id,methods[i],amounts[i],DateTime.Now);
                d.Exec("UPDATE [Заказы] SET StatusText=?,[Discount]=?,Total=? WHERE ID=?","Оплачен",discount,total,id);
                d.Log(u.Id,"Оплата",id+" / "+total+" / скидка "+discount);
                d.Commit();
            }
        }
        static void Acc(Dictionary<int,double> x,int id,double q)
        {
            if(!x.ContainsKey(id))x[id]=0;
            x[id]+=q;
        }
        // После оплаты можно сразу выдать заказ.
        public static void Advance(Employee u,int id,string next)
        {
            Need(u.Sales,"Нет прав");
            Need(next=="Готов"||next=="Выдан","Неверный статус");
            using(var d=new Db(true))
            {
                string state=S(Row(d,"SELECT StatusText FROM [Заказы] WHERE ID=?",id),"StatusText");
                Need(d.Int("SELECT COUNT(*) FROM [Возвраты] WHERE OrderID=?",id)==0,"По заказу уже оформлен возврат");
                if(state==next) return;
                Need(state=="Оплачен" || (state=="Готов" && next=="Выдан"),
                    "Сначала оплатите заказ. Отменённые и выданные заказы менять нельзя.");
                int changed = next=="Выдан"
                    ? d.Exec("UPDATE [Заказы] SET StatusText=?,IssuedAt=? WHERE ID=? AND StatusText=?",next,DateTime.Now,id,state)
                    : d.Exec("UPDATE [Заказы] SET StatusText=? WHERE ID=? AND StatusText=?",next,id,state);
                Need(changed==1,"Заказ уже изменён. Обновите список.");
                d.Log(u.Id,next,id.ToString());
                d.Commit();
            }
        }
        // Отменяю заказ или делаю возврат.
        public static void Cancel(Employee u,int id,string reason,bool refund)
        {
            Need(u.Sales&&reason.Trim().Length>0&&reason.Length<=300,"Укажите причину до 300 символов");
            using(var d=new Db(true))
            {
                var o=Row(d,"SELECT * FROM [Заказы] WHERE ID=?",id);
                string state=S(o,"StatusText");
                Need(state!="Возврат","Возврат уже оформлен");
                Need(refund?u.Shift&&state=="Выдан":new[]
                {
                    "Новый","Оплачен","Готов"
                }
                .Contains(state),"Недопустимая операция");
                Need(state=="Новый"||u.Shift,"Возврат оплаты выполняет старший смены");
                int shift=Shift(d);
                Need(shift>0,"Нет открытой смены");
                Need(d.Exec("UPDATE [Заказы] SET StatusText=? WHERE ID=? AND StatusText=?",refund?"Возврат":"Отменён",id,state)==1,"Заказ изменён другим сотрудником");
                if(state!="Новый")
                {
                    Need(d.Int("SELECT COUNT(*) FROM [Возвраты] WHERE OrderID=?",id)==0,"Возврат уже оформлен");
                    decimal cash=d.Money("SELECT SUM(Amount) FROM [Оплаты] WHERE OrderID=? AND MethodName=?",id,"Наличные");
                    d.Exec("INSERT INTO [Возвраты] (OrderID,ShiftID,EmployeeID,RefundAt,Amount,CashAmount,ReasonText) VALUES (?,?,?,?,?,?,?)",id,shift,u.Id,DateTime.Now,M(o,"Total"),cash,reason);
                    if(state=="Оплачен")foreach(DataRow r in d.Table("SELECT IngredientID,DeltaQty FROM [ДвиженияСклада] WHERE OrderID=? AND MoveType=?",id,"Продажа").Rows)Move(d,u,I(r,"IngredientID"),id,-Convert.ToDouble(r["DeltaQty"]),"Корректировка","Отмена до приготовления");
                }
                d.Log(u.Id,refund?"Возврат":"Отмена",id+": "+reason);
                d.Commit();
            }
        }
        // Меняю количество продуктов на складе.
        public static void Stock(Employee u,int ing,string type,double qty,string reason)
        {
            Need(u.Manager||u.Shift,"Нет прав");
            Need(qty>=0&&!Double.IsNaN(qty)&&!Double.IsInfinity(qty),"Некорректное количество");
            Need(reason.Length<=300,"Описание до 300 символов");
            using(var d=new Db(true))
            {
                var r=Row(d,"SELECT * FROM [Ингредиенты] WHERE ID=?",ing);
                double old=Convert.ToDouble(r["StockQty"]);
                Need(type=="Установить остаток" || qty>0,"Укажите количество больше нуля");
                Need(type=="Приход"||type=="Списание"||type=="Установить остаток","Выберите операцию");
                double delta=type=="Приход"?qty:type=="Списание"?-qty:qty-old;
                Move(d,u,ing,0,delta,type=="Установить остаток"?"Корректировка":type,reason);
                d.Log(u.Id,type+" склада",ing+": "+reason);
                d.Commit();
            }
        }
        public static void OpenShift(Employee u,decimal start)
        {
            Need(u.Shift&&start>=0,"Нет прав или неверная сумма");
            using(var d=new Db(true))
            {
                Need(Shift(d)==0,"Смена уже открыта");
                int id=d.Insert("INSERT INTO [Смены] (EmployeeID,OpenedAt,StartCash,StatusText) VALUES (?,?,?,?)",u.Id,DateTime.Now,start,"Открыта");
                d.Log(u.Id,"Открытие смены",id.ToString());
                d.Commit();
            }
        }
        public static decimal Payments(Db d,int shift,string method)
        {
            return d.Money("SELECT SUM(p.Amount) FROM [Оплаты] p INNER JOIN [Заказы] o ON p.OrderID=o.ID WHERE o.ShiftID=? AND p.MethodName=? AND o.StatusText IN ('Оплачен','Готов','Выдан','Отменён','Возврат')",shift,method);
        }
        public static decimal Expected(Db d,int shift)
        {
            return d.Money("SELECT StartCash FROM [Смены] WHERE ID=?",shift)+Payments(d,shift,"Наличные")-d.Money("SELECT SUM(CashAmount) FROM [Возвраты] WHERE ShiftID=?",shift);
        }
        // Закрываю смену и сверяю деньги.
        public static void CloseShift(Employee u,decimal actual,string reason)
        {
            Need(u.Shift&&actual>=0,"Нет прав или неверная сумма");
            using(var d=new Db(true))
            {
                int id=Shift(d);
                Need(id>0,"Нет открытой смены");
                Need(d.Exec("UPDATE [Смены] SET StatusText=? WHERE ID=? AND StatusText=?","Закрыта",id,"Открыта")==1,"Смена уже закрыта");
                Need(d.Int("SELECT COUNT(*) FROM [Заказы] WHERE ShiftID=? AND StatusText IN ('Новый','Оплачен','Готов')",id)==0,"Нельзя закрыть смену: откройте «Очередь заказов», выдайте оплаченные заказы или отмените новые.");
                decimal diff=Round(actual-Expected(d,id));
                Need(diff==0||reason.Trim().Length>0,"При расхождении нужен комментарий");
                Need(reason.Length<=255,"Комментарий до 255 символов");
                d.Exec("UPDATE [Смены] SET ClosedAt=?,ActualCash=?,Difference=?,NoteText=? WHERE ID=?",DateTime.Now,actual,diff,reason,id);
                d.Log(u.Id,"Закрытие смены",id+" / "+diff);
                d.Commit();
            }
        }
    }
}
