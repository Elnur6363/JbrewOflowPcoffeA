﻿using System;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
namespace BrewFlow
{
    public partial class MainForm
    {
        // Список сотрудников.
        void Admin()
        {
            Page("Администрирование");
            var view=new AdminForm();
            var g=view.g;
            view.g.DataSource = T("SELECT e.ID,e.LoginName AS [Логин],e.FullName AS [Сотрудник],r.RoleName AS [Роль],e.ActiveFlag AS [Активен] FROM [Сотрудники] e INNER JOIN [Роли] r ON e.RoleID=r.ID ORDER BY e.ID");
            view.button1Action = ()=>EditEmployee(0);
            view.button2Action = ()=>EditEmployee(UI.Selected(g));
            view.button3Action = ()=>ShowTable("Журнал событий",T("SELECT EventAt AS [Дата],EmployeeID AS [Сотрудник],ActionName AS [Действие],DetailText AS [Подробности] FROM [Журнал] ORDER BY ID DESC"));
            view.button6Action = ()=>
            {
                string p=Db.Backup();
                using(var d=new Db())
                {
                    d.Log(u.Id,"Резервная копия",p);
                }
                MessageBox.Show("Копия создана:\n"+p);
            }
            ;
            view.button7Action = ()=>MessageBox.Show(Db.PathName);
            view.button8Action = Admin;
            Mount(view);
        }
        // Добавление или изменение сотрудника.
        void EditEmployee(int id)
        {
            var r=id==0?null:T("SELECT * FROM [Сотрудники] WHERE ID=?",id).Rows[0];
            using(var view=new EmployeeForm())
            {
                var f=view;
                var login=view.login;
                view.login.Text = r==null?"":Ops.S(r,"LoginName");
                var name=view.name;
                view.name.Text = r==null?"":Ops.S(r,"FullName");
                var role=view.role;
                UI.BindLookup(view.role, T("SELECT ID,RoleName FROM [Роли] ORDER BY ID"), "RoleName", "ID");
                if(r!=null)role.SelectedValue=Ops.I(r,"RoleID");
                var pass=view.pass;
                pass.UseSystemPasswordChar=true;
                var active=view.active;
                view.active.Checked = r==null||Convert.ToBoolean(r["ActiveFlag"]);
                var box=view.box;
                view.button1Action = ()=>
                {
                    Ops.Need(!String.IsNullOrWhiteSpace(login.Text)&&!String.IsNullOrWhiteSpace(name.Text),"Заполните поля");
                    Ops.Need(id!=u.Id||(active.Checked&&UI.Id(role)==4),"Нельзя отключить собственную учётную запись или изменить её роль");
                    using(var d=new Db(true))
                    {
                        if(id==0)Db.CreateUser(d,login.Text.Trim(),name.Text,UI.Id(role),pass.Text,active.Checked);
                        else
                        {
                            d.Exec("UPDATE [Сотрудники] SET LoginName=?,FullName=?,RoleID=?,ActiveFlag=? WHERE ID=?",login.Text.Trim(),name.Text,UI.Id(role),active.Checked,id);
                            if(pass.Text!="")Db.ChangePassword(d,id,pass.Text);
                        }
                        d.Log(u.Id,"Изменение пользователя",login.Text);
                        d.Commit();
                    }
                    f.DialogResult=DialogResult.OK;
                }
                ;
                if(f.ShowDialog(this)==DialogResult.OK)Admin();
            }
        }
    }
}
