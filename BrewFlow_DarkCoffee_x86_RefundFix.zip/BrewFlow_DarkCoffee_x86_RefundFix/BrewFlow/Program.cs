﻿using System;
using System.Windows.Forms;
namespace BrewFlow
{
    static class Program
    {
        // Отсюда запускается программа.
        [STAThread] static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            try
            {
                Db.Initialize();
            }
            catch(Exception ex)
            {
                MessageBox.Show("Не удалось открыть базу Access.\nПроверьте наличие ACE 32 бит и путь к базе.\n\n"+ex.Message,"BrewFlow",MessageBoxButtons.OK,MessageBoxIcon.Error);
                return;
            }
            if(args.Length>0&&args[0]=="--backup")
            {
                try
                {
                    if(Db.BackupDue())Db.Backup();
                    Environment.ExitCode=0;
                }
                catch
                {
                    Environment.ExitCode=1;
                }
                return;
            }
            try
            {
                if(Db.BackupDue())Db.Backup();
            }
            catch(Exception ex)
            {
                MessageBox.Show("Автоматическая копия не создана. Повторите после закрытия других сеансов.\n"+ex.Message,"Резервирование");
            }
            while(true)
            {
                using(var login=new LoginForm())
                {
                    if(login.ShowDialog()!=DialogResult.OK) break;
                    using(var main=new MainForm(login.Employee))
                    {
                        Application.Run(main);
                        if(!main.Logout) break;
                    }
                }
            }
        }
    }
}
