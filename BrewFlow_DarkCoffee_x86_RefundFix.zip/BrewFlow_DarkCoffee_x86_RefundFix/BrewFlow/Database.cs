﻿using System;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Configuration;
using System.Security.Cryptography;
namespace BrewFlow
{
    public sealed class Db : IDisposable
    {
        public static string PathName;
        static string connectionString;
        OleDbConnection c;
        OleDbTransaction tx;
        // Подключение к базе Access.
        public Db(bool transaction=false)
        {
            c=new OleDbConnection(connectionString);
            c.Open();
            if(transaction) tx=c.BeginTransaction();
        }
        // Подставляю значения в запрос.
        OleDbCommand Command(string sql, object[] args)
        {
            var cmd=new OleDbCommand(sql,c,tx);
            foreach(object a in args)
            {
                var p=cmd.Parameters.Add("?",a is int?OleDbType.Integer:a is decimal?OleDbType.Currency:a is double?OleDbType.Double:a is bool?OleDbType.Boolean:a is DateTime?OleDbType.Date:OleDbType.VarWChar);
                if(p.OleDbType==OleDbType.VarWChar)
                {
                    p.Size=Math.Max(1,Convert.ToString(a).Length);
                    if(p.Size>255)p.OleDbType=OleDbType.LongVarWChar;
                }
                p.Value=(a==null||(a is string&&((string)a).Length==0))?DBNull.Value:a;
            }
            return cmd;
        }
        // Запрос на добавление, изменение или удаление.
        public int Exec(string sql,params object[] a)
        {
            using(var cmd=Command(sql,a)) return cmd.ExecuteNonQuery();
        }
        public object Val(string sql,params object[] a)
        {
            using(var cmd=Command(sql,a)) return cmd.ExecuteScalar();
        }
        public int Int(string sql,params object[] a)
        {
            var x=Val(sql,a);
            return x==null||x==DBNull.Value?0:Convert.ToInt32(x);
        }
        public decimal Money(string sql,params object[] a)
        {
            var x=Val(sql,a);
            return x==null||x==DBNull.Value?0:Convert.ToDecimal(x);
        }
        // Получаю таблицу из базы.
        public DataTable Table(string sql,params object[] a)
        {
            using(var cmd=Command(sql,a)) using(var ad=new OleDbDataAdapter(cmd))
            {
                var t=new DataTable();
                ad.Fill(t);
                return t;
            }
        }
        public int Insert(string sql,params object[] a)
        {
            Exec(sql,a);
            return Int("SELECT @@IDENTITY");
        }
        // Сохраняю изменения в базе.
        public void Commit()
        {
            if(tx!=null)
            {
                tx.Commit();
                tx.Dispose();
                tx=null;
            }
        }
        public void Dispose()
        {
            if(tx!=null)
            {
                try
                {
                    tx.Rollback();
                }
                catch
                {
                }
                tx.Dispose();
            }
            c.Dispose();
        }
        public void Log(int user,string action,string detail)
        {
            Exec("INSERT INTO [Журнал] (EmployeeID,EventAt,ActionName,DetailText) VALUES (?,?,?,?)",user,DateTime.Now,action,detail);
        }
        static void Ensure(Db d,string name,string fields)
        {
            if(!d.c.GetSchema("Tables").Rows.Cast<DataRow>().Any(r=>String.Equals(Convert.ToString(r["TABLE_NAME"]),name,StringComparison.OrdinalIgnoreCase)))d.Exec("CREATE TABLE ["+name+"] ("+fields+")");
        }
        static void Index(Db d,string table,string name,string fields,bool unique)
        {
            var t=d.c.GetOleDbSchemaTable(OleDbSchemaGuid.Indexes,new object[]
            {
                null,null,name,null,table
            }
            );
            if(t==null||t.Rows.Count==0)d.Exec("CREATE "+(unique?"UNIQUE ":"")+"INDEX "+name+" ON ["+table+"] ("+fields+")");
        }
        // Старые названия таблиц меняю один раз.
        // Сначала делаю копию базы, чтобы не потерять данные.
        static void RenameOldTables()
        {
            string[,] names = {
                {"BFRoles", "Роли"},
                {"BFEmployees", "Сотрудники"},
                {"BFMenu", "Меню"},
                {"BFIngredients", "Ингредиенты"},
                {"BFRecipes", "Техкарты"},
                {"BFShifts", "Смены"},
                {"BFOrders", "Заказы"},
                {"BFLines", "СоставЗаказов"},
                {"BFPayments", "Оплаты"},
                {"BFMoves", "ДвиженияСклада"},
                {"BFRefunds", "Возвраты"},
                {"BFPriceHistory", "ИсторияЦен"},
                {"BFLog", "Журнал"},
                {"BFSettings", "Настройки"},
            };
            string[] tables;
            using (var d = new Db())
                tables = d.c.GetSchema("Tables").Rows.Cast<DataRow>()
                    .Select(r => Convert.ToString(r["TABLE_NAME"])).ToArray();
            bool needed = false;
            for (int i = 0; i < names.GetLength(0); i++)
            {
                if (!tables.Contains(names[i, 0], StringComparer.OrdinalIgnoreCase)) continue;
                if (tables.Contains(names[i, 1], StringComparer.OrdinalIgnoreCase))
                    throw new Exception("В базе одновременно есть таблицы " + names[i, 0] + " и " + names[i, 1] + ". Данные не изменены.");
                needed = true;
            }
            if (!needed) return;
            OleDbConnection.ReleaseObjectPool();
            if (File.Exists(Path.ChangeExtension(PathName, ".laccdb")))
                throw new IOException("Закройте Access и старую программу перед обновлением базы.");
            string folder = Path.GetDirectoryName(PathName);
            string token = Guid.NewGuid().ToString("N");
            string temp = Path.Combine(folder, "Migration_" + token + ".accdb");
            string backupFolder = Path.Combine(folder, "Backups");
            Directory.CreateDirectory(backupFolder);
            string backup = Path.Combine(backupFolder, "До_переименования_" + token + ".accdb");
            dynamic engine = null, database = null, definitions = null, table = null;
            try
            {
                using (var input = new FileStream(PathName, FileMode.Open, FileAccess.Read, FileShare.None))
                using (var output = File.Create(temp)) input.CopyTo(output);
                Type dao = Type.GetTypeFromProgID("DAO.DBEngine.120");
                if (dao == null) throw new Exception("Для обновления старой базы нужен установленный Access/ACE x86 (DAO).");
                engine = Activator.CreateInstance(dao);
                database = engine.OpenDatabase(temp, true, false, "");
                definitions = database.TableDefs;
                for (int i = 0; i < names.GetLength(0); i++)
                {
                    if (!tables.Contains(names[i, 0], StringComparer.OrdinalIgnoreCase)) continue;
                    table = definitions[names[i, 0]];
                    table.Name = names[i, 1];
                    System.Runtime.InteropServices.Marshal.FinalReleaseComObject((object)table);
                    table = null;
                }
                System.Runtime.InteropServices.Marshal.FinalReleaseComObject((object)definitions);
                definitions = null;
                database.Close();
                System.Runtime.InteropServices.Marshal.FinalReleaseComObject((object)database);
                database = null;
                System.Runtime.InteropServices.Marshal.FinalReleaseComObject((object)engine);
                engine = null;
                if (File.Exists(Path.ChangeExtension(PathName, ".laccdb")))
                    throw new IOException("Закройте Access перед обновлением базы.");
                File.Replace(temp, PathName, backup);
            }
            finally
            {
                if (table != null) System.Runtime.InteropServices.Marshal.FinalReleaseComObject((object)table);
                if (definitions != null) System.Runtime.InteropServices.Marshal.FinalReleaseComObject((object)definitions);
                if (database != null)
                {
                    try { database.Close(); } catch { }
                    System.Runtime.InteropServices.Marshal.FinalReleaseComObject((object)database);
                }
                if (engine != null) System.Runtime.InteropServices.Marshal.FinalReleaseComObject((object)engine);
                if (File.Exists(temp)) File.Delete(temp);
            }
        }
        public static void Initialize()
        {
            string configured = ConfigurationManager.AppSettings["DatabasePath"];
            string root = AppDomain.CurrentDomain.BaseDirectory;
            // Здесь ищу базу рядом с файлом проекта.
            DirectoryInfo folder = new DirectoryInfo(root);
            while (folder != null && !File.Exists(Path.Combine(folder.FullName, "BrewFlow.csproj")))
                folder = folder.Parent;
            string projectFolder = folder == null ? root : folder.FullName;
            PathName = String.IsNullOrWhiteSpace(configured)
                ? Path.Combine(projectFolder, "BrewFlow.accdb") : Path.GetFullPath(configured);
            if (!File.Exists(PathName))
                throw new FileNotFoundException("База данных не найдена", PathName);

            Exception last=null;
            foreach(string provider in new[]
            {
                "Microsoft.ACE.OLEDB.12.0","Microsoft.ACE.OLEDB.16.0"
            }
            )
            {
                var b=new OleDbConnectionStringBuilder();
                b.Provider=provider;
                b.DataSource=PathName;
                connectionString=b.ConnectionString;
                try
                {
                    using(var d=new Db())
                    {
                    }
                    last=null;
                    break;
                }
                catch(Exception ex)
                {
                    last=ex;
                }
            }
            if(last!=null)throw last;
            RenameOldTables();
            bool needsRecipeUpdate;
            using(var d=new Db())
            {
                needsRecipeUpdate = TableExists(d,"Настройки") &&
                    d.Int("SELECT COUNT(*) FROM [Настройки] WHERE SettingName=?","Initialized")>0 &&
                    d.Int("SELECT COUNT(*) FROM [Настройки] WHERE SettingName=?","Recipes2026V2")==0;
            }
            if(needsRecipeUpdate) Backup();
            using(var d=new Db())
            {
                Ensure(d,"Роли","ID COUNTER PRIMARY KEY, RoleName TEXT(50)");
                Ensure(d,"Сотрудники","ID COUNTER PRIMARY KEY, LoginName TEXT(50), FullName TEXT(100), RoleID LONG, SaltText TEXT(100), HashText TEXT(100), ActiveFlag YESNO");
                Ensure(d,"Меню","ID COUNTER PRIMARY KEY, ProductName TEXT(100), CategoryName TEXT(30), Price CURRENCY, ActiveFlag YESNO, ImageName TEXT(100)");
                Ensure(d,"Ингредиенты","ID COUNTER PRIMARY KEY, IngredientName TEXT(100), UnitName TEXT(10), StockQty DOUBLE, MinQty DOUBLE");
                Ensure(d,"Техкарты","ID COUNTER PRIMARY KEY, ProductID LONG, IngredientID LONG, Qty DOUBLE");
                Ensure(d,"Смены","ID COUNTER PRIMARY KEY, EmployeeID LONG, OpenedAt DATETIME, ClosedAt DATETIME, StartCash CURRENCY, ActualCash CURRENCY, Difference CURRENCY, StatusText TEXT(20), NoteText TEXT(255)");
                Ensure(d,"Заказы","ID COUNTER PRIMARY KEY, OrderNo TEXT(30), ShiftID LONG, EmployeeID LONG, CreatedAt DATETIME, IssuedAt DATETIME, StatusText TEXT(20), NoteText MEMO, Total CURRENCY, [Discount] CURRENCY");
                EnsureDiscountColumn(d);
                Ensure(d,"СоставЗаказов","ID COUNTER PRIMARY KEY, OrderID LONG, ProductID LONG, ProductName TEXT(100), CategoryName TEXT(30), Qty LONG, UnitPrice CURRENCY");
                Ensure(d,"Оплаты","ID COUNTER PRIMARY KEY, OrderID LONG, MethodName TEXT(20), Amount CURRENCY, PaidAt DATETIME");
                Ensure(d,"ДвиженияСклада","ID COUNTER PRIMARY KEY, IngredientID LONG, EmployeeID LONG, OrderID LONG, MovedAt DATETIME, MoveType TEXT(30), DeltaQty DOUBLE, ReasonText MEMO");
                Ensure(d,"Возвраты","ID COUNTER PRIMARY KEY, OrderID LONG, ShiftID LONG, EmployeeID LONG, RefundAt DATETIME, Amount CURRENCY, CashAmount CURRENCY, ReasonText MEMO");
                Ensure(d,"ИсторияЦен","ID COUNTER PRIMARY KEY, ProductID LONG, EmployeeID LONG, Price CURRENCY, ValidFrom DATETIME");
                Ensure(d,"Журнал","ID COUNTER PRIMARY KEY, EmployeeID LONG, EventAt DATETIME, ActionName TEXT(80), DetailText MEMO");
                Ensure(d,"Настройки","ID COUNTER PRIMARY KEY, SettingName TEXT(50), SettingValue TEXT(100)");
                Index(d,"Сотрудники","UXBFLogin","LoginName",true);
                Index(d,"Заказы","UXBFOrderNo","OrderNo",true);
                Index(d,"Техкарты","UXBFRecipe","ProductID,IngredientID",true);
                Index(d,"Заказы","IXBFOrderDate","CreatedAt",false);
                Index(d,"СоставЗаказов","IXBFLineOrder","OrderID",false);
                Index(d,"Оплаты","IXBFPayOrder","OrderID",false);
                Index(d,"Возвраты","UXBFRefund","OrderID",true);
                Index(d,"Настройки","UXBFSetting","SettingName",true);
            }
            bool hasOriginalProducts;
            using(var d=new Db()) hasOriginalProducts=TableExists(d,"Products");
            using(var d=new Db(true))
            {
                if(d.Int("SELECT COUNT(*) FROM [Настройки] WHERE SettingName=?","Initialized")==0)
                {
                    foreach(string role in new[]
                    {
                        "Бариста-кассир","Старший смены","Управляющий","Администратор"
                    }
                    )d.Exec("INSERT INTO [Роли] (RoleName) VALUES (?)",role);
                    string[] users=
                    {
                        "barista","shift","manager","admin"
                    }
                    ;
                    string[] fullNames=
                    {
                        "Бариста-кассир","Старший смены","Управляющий","Администратор"
                    }
                    ;
                    for(int i=0;i<4;i++)CreateUser(d,users[i],fullNames[i],i+1,"Brew2026!",true);
                    string[] names=
                    {
                        "Кофе в зерне","Молоко","Сироп ванильный","Стаканы 300 мл","Вода","Чизкейк","Круассан"
                    }
                    ;
                    string[] units=
                    {
                        "кг","л","л","шт","л","шт","шт"
                    }
                    ;
                    double[] stocks=
                    {
                        4.8,7.2,1.6,420,50,20,20
                    }
                    , mins=
                    {
                        2,8,1,200,5,5,5
                    }
                    ;
                    for(int i=0;i<names.Length;i++)d.Exec("INSERT INTO [Ингредиенты] (IngredientName,UnitName,StockQty,MinQty) VALUES (?,?,?,?)",names[i],units[i],stocks[i],mins[i]);
                    string[] products = { "Капучино", "Латте", "Американо", "Чизкейк", "Круасан" };
                    string[] cats = { "Кофе", "Кофе", "Кофе", "Десерты", "Десерты" };
                    decimal[] prices = { 200m, 220m, 140m, 250m, 180m };
                    string[] imgs = { "kapuchino.jpg", "latte.jpg", "americano.jpg", "chizkayke.jpg", "kruasan.jpg" };
                    for (int i = 0; i < products.Length; i++)
                    {
                        object originalPrice = hasOriginalProducts ? d.Val("SELECT [Price] FROM [Products] WHERE [ProductName]=?", products[i]) : null;
                        if (originalPrice != null && originalPrice != DBNull.Value) prices[i] = Convert.ToDecimal(originalPrice);
                        int id = d.Insert("INSERT INTO [Меню] (ProductName,CategoryName,Price,ActiveFlag,ImageName) VALUES (?,?,?,?,?)", products[i],cats[i],prices[i],true,imgs[i]);
                        d.Exec("INSERT INTO [ИсторияЦен] (ProductID,EmployeeID,Price,ValidFrom) VALUES (?,?,?,?)",id,0,prices[i],DateTime.Now);
                    }
                    d.Exec("INSERT INTO [Настройки] (SettingName,SettingValue) VALUES (?,?)","Initialized","1");
                }
                UpdateRecipes(d);
                // Исправляю статус старых возвратов, деньги повторно не списываю.
                foreach(DataRow r in d.Table("SELECT o.ID FROM [Заказы] o INNER JOIN [Возвраты] v ON o.ID=v.OrderID WHERE o.StatusText=?", "Выдан").Rows)
                    d.Exec("UPDATE [Заказы] SET StatusText=? WHERE ID=? AND StatusText=?", "Возврат", Convert.ToInt32(r["ID"]), "Выдан");
                d.Commit();
            }
            try { CleanUnusedTables(); }
            catch(Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("Старые таблицы пока не удалены. Рабочие данные сохранены.\nЗакройте Access и перезапустите программу.\n"+ex.Message,"Очистка базы");
            }
        }
        static void EnsureDiscountColumn(Db d)
        {
            bool exists = d.Table("SELECT TOP 1 * FROM [Заказы]").Columns.Contains("Discount");
            if(!exists) d.Exec("ALTER TABLE [Заказы] ADD COLUMN [Discount] CURRENCY");
            d.Exec("UPDATE [Заказы] SET [Discount]=0 WHERE [Discount] IS NULL");
        }
        // Рецепты обновляю один раз, потом не трогаю.
        static void UpdateRecipes(Db d)
        {
            if(d.Int("SELECT COUNT(*) FROM [Настройки] WHERE SettingName=?","Recipes2026V2")>0) return;
            foreach(string name in new[] {"Чай", "Лёд", "Лед"})
            {
                foreach(DataRow r in d.Table("SELECT ID FROM [Ингредиенты] WHERE IngredientName=?",name).Rows)
                {
                    int id=Convert.ToInt32(r["ID"]);
                    d.Exec("DELETE FROM [Техкарты] WHERE IngredientID=?",id);
                    // Оставляю ингредиент, если он есть в истории склада.
                    if(d.Int("SELECT COUNT(*) FROM [ДвиженияСклада] WHERE IngredientID=?",id)==0)
                        d.Exec("DELETE FROM [Ингредиенты] WHERE ID=?",id);
                }
            }
            // Сколько продуктов нужно на одну порцию (кг, л, шт).
            string[] products={"Капучино","Латте","Американо","Чизкейк","Круасан"};
            string[] ingredients={"Кофе в зерне","Молоко","Вода","Стаканы 300 мл","Чизкейк","Круассан"};
            double[,] recipe={
                {0.018,0.150,0.040,1,0,0},
                {0.018,0.220,0.040,1,0,0},
                {0.018,0,0.250,1,0,0},
                {0,0,0,0,1,0},
                {0,0,0,0,0,1}
            };
            for(int i=0;i<products.Length;i++)
            {
                int product=d.Int("SELECT TOP 1 ID FROM [Меню] WHERE ProductName=?",products[i]);
                if(product==0) continue;
                d.Exec("DELETE FROM [Техкарты] WHERE ProductID=?",product);
                for(int j=0;j<ingredients.Length;j++)
                {
                    if(recipe[i,j]==0) continue;
                    int ingredient=d.Int("SELECT TOP 1 ID FROM [Ингредиенты] WHERE IngredientName=?",ingredients[j]);
                    if(ingredient==0) throw new Exception("Не найден ингредиент: "+ingredients[j]);
                    d.Exec("INSERT INTO [Техкарты] (ProductID,IngredientID,Qty) VALUES (?,?,?)",product,ingredient,recipe[i,j]);
                }
            }
            d.Exec("INSERT INTO [Настройки] (SettingName,SettingValue) VALUES (?,?)","Recipes2026V2","1");
        }
        // Список нужных таблиц.
        static readonly string[] UsedTables = { "Роли", "Сотрудники", "Меню", "Ингредиенты", "Техкарты", "Смены", "Заказы", "СоставЗаказов", "Оплаты", "ДвиженияСклада", "Возвраты", "ИсторияЦен", "Журнал", "Настройки" };
        static bool TableExists(Db d,string name)
        {
            return d.c.GetSchema("Tables").Rows.Cast<DataRow>().Any(r=>String.Equals(Convert.ToString(r["TABLE_NAME"]),name,StringComparison.OrdinalIgnoreCase));
        }
        // Убираю лишние таблицы, сначала сохраняю копию базы.
        static void CleanUnusedTables()
        {
            string[] unused;
            using(var d=new Db()) unused=d.c.GetSchema("Tables").Rows.Cast<DataRow>()
                .Where(r=>Convert.ToString(r["TABLE_TYPE"])=="TABLE")
                .Select(r=>Convert.ToString(r["TABLE_NAME"]))
                .Where(n=>!n.StartsWith("MSys",StringComparison.OrdinalIgnoreCase)&&!UsedTables.Contains(n,StringComparer.OrdinalIgnoreCase)).ToArray();
            if(unused.Length==0) return;
            OleDbConnection.ReleaseObjectPool();
            string folder=Path.GetDirectoryName(PathName);
            string token=Guid.NewGuid().ToString("N");
            string temp=Path.Combine(folder,"Cleanup_"+token+".accdb");
            string backupFolder=Path.Combine(folder,"Backups");
            Directory.CreateDirectory(backupFolder);
            string backup=Path.Combine(backupFolder,"До_очистки_"+token+".accdb");
            dynamic engine=null, database=null;
            try
            {
                using(var source=new FileStream(PathName,FileMode.Open,FileAccess.Read,FileShare.None))
                using(var dest=File.Create(temp)) source.CopyTo(dest);
                Type dao=Type.GetTypeFromProgID("DAO.DBEngine.120");
                if(dao==null) throw new Exception("Для очистки старых таблиц нужен Access/ACE x86 (DAO).");
                engine=Activator.CreateInstance(dao);
                database=engine.OpenDatabase(temp,true,false,"");
                // Убираю связи только у лишних таблиц.
                for(int i=database.Relations.Count-1;i>=0;i--)
                {
                    dynamic relation=database.Relations[i];
                    string a=Convert.ToString(relation.Table), b=Convert.ToString(relation.ForeignTable), n=Convert.ToString(relation.Name);
                    System.Runtime.InteropServices.Marshal.FinalReleaseComObject((object)relation);
                    if(unused.Contains(a,StringComparer.OrdinalIgnoreCase)||unused.Contains(b,StringComparer.OrdinalIgnoreCase)) database.Relations.Delete(n);
                }
                foreach(string name in unused) database.TableDefs.Delete(name);
                database.Close();
                System.Runtime.InteropServices.Marshal.FinalReleaseComObject((object)database); database=null;
                System.Runtime.InteropServices.Marshal.FinalReleaseComObject((object)engine); engine=null;
                File.Replace(temp,PathName,backup);
            }
            finally
            {
                if(database!=null) { try {database.Close();} catch {} System.Runtime.InteropServices.Marshal.FinalReleaseComObject((object)database); }
                if(engine!=null) System.Runtime.InteropServices.Marshal.FinalReleaseComObject((object)engine);
                if(File.Exists(temp)) File.Delete(temp);
            }
        }
        public static string Hash(string password,string salt)
        {
            using(var k=new Rfc2898DeriveBytes(password,Convert.FromBase64String(salt),100000))return Convert.ToBase64String(k.GetBytes(32));
        }
        public static void CreateUser(Db d,string login,string name,int role,string password,bool active)
        {
            if(password.Length<8)throw new Exception("Пароль не менее 8 символов");
            byte[] b=new byte[16];
            using(var r=new RNGCryptoServiceProvider())r.GetBytes(b);
            string salt=Convert.ToBase64String(b);
            d.Exec("INSERT INTO [Сотрудники] (LoginName,FullName,RoleID,SaltText,HashText,ActiveFlag) VALUES (?,?,?,?,?,?)",login,name,role,salt,Hash(password,salt),active);
        }
        public static void ChangePassword(Db d,int id,string password)
        {
            if(password.Length<8)throw new Exception("Пароль не менее 8 символов");
            byte[] b=new byte[16];
            using(var r=new RNGCryptoServiceProvider())r.GetBytes(b);
            string salt=Convert.ToBase64String(b);
            d.Exec("UPDATE [Сотрудники] SET SaltText=?,HashText=? WHERE ID=?",salt,Hash(password,salt),id);
        }
        public static bool BackupDue()
        {
            string dir=Path.Combine(Path.GetDirectoryName(PathName),"Backups");
            return !Directory.Exists(dir)||!Directory.GetFiles(dir,"BrewFlow_*.accdb").Any(f=>File.GetLastWriteTime(f).Date==DateTime.Today);
        }
        // Делаю запасную копию базы.
        public static string Backup()
        {
            OleDbConnection.ReleaseObjectPool();
            string dir=Path.Combine(Path.GetDirectoryName(PathName),"Backups");
            Directory.CreateDirectory(dir);
            string p=Path.Combine(dir,"BrewFlow_"+DateTime.Now.ToString("yyyyMMdd_HHmmss_fff")+".accdb");
            using(var src=new FileStream(PathName,FileMode.Open,FileAccess.Read,FileShare.None))using(var dst=File.Create(p))src.CopyTo(dst);
            foreach(var f in Directory.GetFiles(dir,"BrewFlow_*.accdb"))if(File.GetLastWriteTime(f)<DateTime.Now.AddDays(-14))File.Delete(f);
            return p;
        }
    }
    public class Employee
    {
        public int Id,Role;
        public string Name,RoleName;
        public bool Sales
        {
            get
            {
                return Role==1||Role==2;
            }
        }
        public bool Shift
        {
            get
            {
                return Role==2;
            }
        }
        public bool Manager
        {
            get
            {
                return Role==3;
            }
        }
        public bool Admin
        {
            get
            {
                return Role==4;
            }
        }

    }
}
